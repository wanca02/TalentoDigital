package guardian01Zoo;

public class Mammal {
	public int energyLevel=100;
	
	public void displayEnergy() {
		System.out.println(energyLevel);
	}
}

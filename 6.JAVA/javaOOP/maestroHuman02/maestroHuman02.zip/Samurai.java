package maestroHuman;

public class Samurai extends Human{
	private int cc=6;
	public Samurai() {
		this.setHealth(200);
		cc++;
	}
}

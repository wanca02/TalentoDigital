package maestroHuman;

public class Ninja extends Human{
	
	public Ninja() {
		this.setStealth(10);
	}
	
}

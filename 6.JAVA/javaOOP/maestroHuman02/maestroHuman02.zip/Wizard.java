package maestroHuman;

public class Wizard extends Human{
	
	public Wizard() {
		this.setHealth(50);
		this.setIntelligence(8);
	}
	
}

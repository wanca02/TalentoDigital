package maestroHuman;

public class HumanTest extends setUpPlayers{

	public static void main(String[] args) {

		w.displayHealth(); n.displayHealth(); s.displayHealth();
		
		n.attack(w);
		//w.usedSkill("Heal",s);
		
		
	}

}

package maestroHuman;

public class setUpPlayers {
	static Human w = new Human(3,3,8,50,"Wizard");
	static Human n = new Human(3,10,3,100,"Ninja");
	static Human s = new Human(3,3,3,200,"Samurai");
	static Human s2 = new Human(3,3,3,200,"Samurai02");
}

package maestroHuman;

public class NinjaMain extends setUpPlayers{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		n.steal(s);
		n.runAway();
	}
}

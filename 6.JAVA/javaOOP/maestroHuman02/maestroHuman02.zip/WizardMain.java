package maestroHuman;


public class WizardMain extends setUpPlayers{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		w.heal(s);
		w.fireBall(n);
	}

}

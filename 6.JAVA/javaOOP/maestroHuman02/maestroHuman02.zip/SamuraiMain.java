package maestroHuman;

public class SamuraiMain extends setUpPlayers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		s.deathBlow(n);
		s.meditate();
		s.howMany();
	}

}

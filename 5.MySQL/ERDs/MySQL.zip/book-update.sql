update libro
set autor="autor4"
where id=3; 
insert into libro(tilte,autor)
values("titulo 1","autor 1"),
("titulo 2","autor 2"),
("titulo 3","autor 3"),
("titulo 4","autor 4");
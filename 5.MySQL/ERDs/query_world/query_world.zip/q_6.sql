select name,government_form,life_expectancy,capital from countries
where government_form="Constitutional Monarchy"
and capital>200
and life_expectancy>75;



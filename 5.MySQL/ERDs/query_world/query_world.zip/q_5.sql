select name,population from countries
where surface_area<501
and population>100000;
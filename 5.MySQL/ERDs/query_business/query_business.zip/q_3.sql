select client_id,domain_name from sites
where client_id=10;
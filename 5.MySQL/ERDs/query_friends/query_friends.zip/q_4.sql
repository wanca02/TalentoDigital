#create schema friends;

/*insert into friends.users 
values(6,"Waldo","Wyp","2020-02-17 10:30:00",null);*/

/*insert into friends.friendships
values
	(7,2,6,"2020-02-17 10:30:00",null),
	(8,4,6,"2020-02-17 10:30:00",null),
	(9,5,6,"2020-02-17 10:30:00",null);*/

/*delete from friends.friendships
where user_id=6;
#where id=6;*/
